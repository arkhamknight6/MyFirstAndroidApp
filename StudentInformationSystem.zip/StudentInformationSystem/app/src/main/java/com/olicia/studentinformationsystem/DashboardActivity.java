
package com.olicia.studentinformationsystem;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class DashboardActivity extends Activity {

    int charcoal = Color.rgb(32, 32, 32);
    int background = Color.rgb(244, 240, 230);
    int gray = Color.rgb(133, 136, 139);
    int white = Color.WHITE;
    int border = Color.rgb(226, 224, 218);

    DatabaseHelper databaseHelper;
    TextView studentCount;

    int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseHelper = new DatabaseHelper(this);

        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(charcoal);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        );

        showDashboard();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (databaseHelper != null && studentCount != null) {
            studentCount.setText(
                    String.valueOf(databaseHelper.getStudentCount())
            );
        }
    }

    GradientDrawable createBackground(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    GradientDrawable createBorder(int color, int stroke, int radius) {
        GradientDrawable drawable = createBackground(color, radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    TextView createText(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setTypeface(Typeface.create(
                bold ? "sans-serif-medium" : "sans-serif",
                Typeface.NORMAL
        ));
        return text;
    }

    void showDashboard() {

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(background);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(24), dp(35), dp(24), dp(30));

        TextView logo = createText(
                "S T U D E N T   I N F O R M A T I O N   S Y S T E M",
                10, gray, true
        );

        TextView adminLabel = createText(
                "ADMINISTRATION", 11, gray, true
        );

        TextView welcome = createText(
                "Welcome back,\nAdministrator.",
                30, charcoal, true
        );

        TextView subtitle = createText(
                "Manage your student records and academic information.",
                14, gray, false
        );

        TextView overview = createText(
                "Overview", 21, charcoal, true
        );

        LinearLayout studentCard = new LinearLayout(this);
        studentCard.setOrientation(LinearLayout.VERTICAL);
        studentCard.setPadding(dp(23), dp(25), dp(23), dp(25));
        studentCard.setBackground(createBackground(charcoal, 22));
        studentCard.setElevation(dp(3));

        TextView cardLabel = createText(
                "TOTAL REGISTERED STUDENTS",
                11, Color.rgb(205, 205, 205), true
        );

        studentCount = createText(
                String.valueOf(databaseHelper.getStudentCount()),
                48, white, true
        );

        TextView description = createText(
                "Student records in the system",
                13, Color.rgb(205, 205, 205), false
        );

        studentCard.addView(cardLabel);
        addSpace(studentCard, 15);
        studentCard.addView(studentCount);
        addSpace(studentCard, 5);
        studentCard.addView(description);

        TextView actionsTitle = createText(
                "Manage Students", 21, charcoal, true
        );

        LinearLayout registration = createMenuItem(
                "＋",
                "Register a Student",
                "Add a new student record"
        );

        LinearLayout directory = createMenuItem(
                "☷",
                "Student Directory",
                "View and manage student records"
        );

        TextView logout = createText(
                "LOG OUT     →", 13, white, true
        );

        logout.setGravity(Gravity.CENTER);
        logout.setBackground(createBackground(charcoal, 14));
        logout.setMinHeight(dp(58));
        logout.setClickable(true);
        logout.setFocusable(true);

        main.addView(logo);
        addSpace(main, 30);
        main.addView(adminLabel);
        addSpace(main, 10);
        main.addView(welcome);
        addSpace(main, 10);
        main.addView(subtitle);
        addSpace(main, 35);
        main.addView(overview);
        addSpace(main, 16);
        main.addView(studentCard);
        addSpace(main, 35);
        main.addView(actionsTitle);
        addSpace(main, 16);
        main.addView(registration);
        addSpace(main, 13);
        main.addView(directory);
        addSpace(main, 30);
        main.addView(logout);

        scrollView.addView(main);
        setContentView(scrollView);

        registration.setOnClickListener(v -> {
            Intent intent = new Intent(
                    DashboardActivity.this,
                    StudentRegistrationActivity.class
            );
            startActivity(intent);
        });

        directory.setOnClickListener(v -> {
            Intent intent = new Intent(
                    DashboardActivity.this,
                    StudentDirectoryActivity.class
            );
            startActivity(intent);
        });

        logout.setOnClickListener(v -> {

            Intent intent = new Intent(
                    DashboardActivity.this,
                    MainActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);
            finish();
        });
    }

    LinearLayout createMenuItem(
            String symbol,
            String title,
            String description
    ) {

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.HORIZONTAL);
        container.setGravity(Gravity.CENTER_VERTICAL);
        container.setPadding(dp(18), dp(17), dp(18), dp(17));
        container.setBackground(createBorder(white, border, 17));
        container.setElevation(dp(1));
        container.setClickable(true);
        container.setFocusable(true);

        TextView icon = createText(
                symbol, 25, charcoal, true
        );

        icon.setGravity(Gravity.CENTER);
        icon.setBackground(createBackground(background, 13));

        container.addView(icon, new LinearLayout.LayoutParams(
                dp(48), dp(48)
        ));

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setPadding(dp(15), 0, 0, 0);

        TextView heading = createText(
                title, 15, charcoal, true
        );

        TextView subheading = createText(
                description, 12, gray, false
        );

        details.addView(heading);
        addSpace(details, 5);
        details.addView(subheading);

        container.addView(details, new LinearLayout.LayoutParams(
                0, -2, 1
        ));

        TextView arrow = createText(
                "›", 27, gray, false
        );

        container.addView(arrow);

        return container;
    }

    void addSpace(LinearLayout layout, int height) {
        View space = new View(this);
        layout.addView(space, new LinearLayout.LayoutParams(
                1, dp(height)
        ));
    }
}
