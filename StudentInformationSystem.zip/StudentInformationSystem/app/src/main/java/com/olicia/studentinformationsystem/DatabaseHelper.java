package com.olicia.studentinformationsystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "StudentInformation.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE students (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "student_no TEXT NOT NULL UNIQUE, " +
                "lastname TEXT NOT NULL, " +
                "firstname TEXT NOT NULL, " +
                "middlename TEXT, " +
                "program TEXT NOT NULL, " +
                "year_level TEXT NOT NULL)";

        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    private boolean isValidStudentData(
            String studentNo,
            String program,
            String yearLevel) {

        if (studentNo == null ||
                !studentNo.matches("[0-9]{4}-[0-9]+")) {
            return false;
        }

        if (program == null ||
                !(program.equals("BSCS-ML") ||
                        program.equals("BSCS-DF"))) {
            return false;
        }

        if (yearLevel == null ||
                !(yearLevel.equals("1st Year") ||
                        yearLevel.equals("2nd Year") ||
                        yearLevel.equals("3rd Year") ||
                        yearLevel.equals("4th Year"))) {
            return false;
        }

        return true;
    }

    public boolean addStudent(
            String studentNo,
            String lastname,
            String firstname,
            String middlename,
            String program,
            String yearLevel) {

        if (!isValidStudentData(studentNo, program, yearLevel) ||
                lastname == null || lastname.trim().isEmpty() ||
                firstname == null || firstname.trim().isEmpty()) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("student_no", studentNo);
        values.put("lastname", lastname);
        values.put("firstname", firstname);
        values.put("middlename", middlename);
        values.put("program", program);
        values.put("year_level", yearLevel);

        long result = db.insert("students", null, values);

        db.close();

        return result != -1;
    }

    public Cursor getAllStudents() {
        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM students ORDER BY lastname ASC",
                null
        );
    }

    public Cursor searchStudents(String keyword) {
        SQLiteDatabase db = getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM students WHERE student_no LIKE ? " +
                        "OR lastname LIKE ? OR firstname LIKE ? " +
                        "ORDER BY lastname ASC",
                new String[]{
                        "%" + keyword + "%",
                        "%" + keyword + "%",
                        "%" + keyword + "%"
                }
        );
    }

    public boolean updateStudent(
            int id,
            String studentNo,
            String lastname,
            String firstname,
            String middlename,
            String program,
            String yearLevel) {

        if (!isValidStudentData(studentNo, program, yearLevel) ||
                lastname == null || lastname.trim().isEmpty() ||
                firstname == null || firstname.trim().isEmpty()) {
            return false;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("student_no", studentNo);
        values.put("lastname", lastname);
        values.put("firstname", firstname);
        values.put("middlename", middlename);
        values.put("program", program);
        values.put("year_level", yearLevel);

        int result = db.update(
                "students",
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        db.close();

        return result > 0;
    }

    public boolean deleteStudent(int id) {
        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(
                "students",
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        db.close();

        return result > 0;
    }

    public int getStudentCount() {
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM students",
                null
        );

        int count = 0;

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();
        db.close();

        return count;
    }
}