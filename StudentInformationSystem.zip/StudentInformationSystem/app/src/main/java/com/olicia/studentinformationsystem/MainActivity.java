
package com.olicia.studentinformationsystem;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    int charcoal = Color.rgb(32, 32, 32);
    int background = Color.rgb(244, 240, 230);
    int gray = Color.rgb(133, 136, 139);
    int white = Color.WHITE;
    int border = Color.rgb(226, 224, 218);

    int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(charcoal);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        );
        showLogin();
    }

    GradientDrawable createBackground(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    GradientDrawable createBorder(int color, int stroke, int radius) {
        GradientDrawable drawable = createBackground(color, radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    TextView createText(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setTypeface(
                Typeface.create(
                        bold ? "sans-serif-medium" : "sans-serif",
                        Typeface.NORMAL
                )
        );
        return text;
    }

    EditText createInput(String hint, int inputType) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextSize(14);
        input.setSingleLine(true);
        input.setInputType(inputType);
        input.setPadding(dp(17), dp(10), dp(17), dp(10));
        input.setTextColor(charcoal);
        input.setHintTextColor(gray);
        input.setBackground(createBorder(white, border, 14));
        input.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        return input;
    }

    void showLogin() {

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(background);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setGravity(Gravity.CENTER);
        main.setPadding(dp(25), dp(35), dp(25), dp(35));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(24), dp(32), dp(24), dp(30));
        card.setBackground(createBackground(white, 24));
        card.setElevation(dp(4));

        TextView logo = createText(
                "S T U D E N T   I N F O R M A T I O N",
                11, gray, true
        );
        logo.setGravity(Gravity.CENTER);

        TextView brand = createText(
                "S Y S T E M",
                11, charcoal, true
        );
        brand.setGravity(Gravity.CENTER);

        TextView title = createText(
                "Welcome back.",
                31, charcoal, true
        );

        TextView subtitle = createText(
                "Sign in to access your account and continue.",
                14, gray, false
        );

        TextView usernameLabel = createText(
                "USERNAME", 11, charcoal, true
        );

        EditText username = createInput(
                "Enter your username",
                InputType.TYPE_CLASS_TEXT
        );

        TextView passwordLabel = createText(
                "PASSWORD", 11, charcoal, true
        );

        EditText password = createInput(
                "Enter your password",
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        TextView login = createText(
                "SIGN IN     →", 14, white, true
        );
        login.setGravity(Gravity.CENTER);
        login.setBackground(createBackground(charcoal, 14));
        login.setMinHeight(dp(58));
        login.setClickable(true);
        login.setFocusable(true);
        login.setElevation(dp(2));

        LinearLayout registerLayout = new LinearLayout(this);
        registerLayout.setGravity(Gravity.CENTER);
        registerLayout.setOrientation(LinearLayout.HORIZONTAL);

        TextView prompt = createText(
                "New student? ", 13, gray, false
        );

        TextView register = createText(
                "Register here", 13, charcoal, true
        );
        register.setPadding(dp(5), dp(10), dp(5), dp(10));
        register.setClickable(true);
        register.setFocusable(true);

        registerLayout.addView(prompt);
        registerLayout.addView(register);

        TextView footer = createText(
                "STUDENT INFORMATION SYSTEM  •  2026",
                10, gray, true
        );
        footer.setGravity(Gravity.CENTER);

        addSpace(card, 5);
        card.addView(logo);
        card.addView(brand);
        addSpace(card, 38);
        card.addView(title);
        addSpace(card, 8);
        card.addView(subtitle);
        addSpace(card, 35);
        card.addView(usernameLabel);
        addSpace(card, 9);
        card.addView(username, new LinearLayout.LayoutParams(
                -1, dp(55)
        ));
        addSpace(card, 20);
        card.addView(passwordLabel);
        addSpace(card, 9);
        card.addView(password, new LinearLayout.LayoutParams(
                -1, dp(55)
        ));
        addSpace(card, 28);
        card.addView(login, new LinearLayout.LayoutParams(
                -1, dp(58)
        ));
        addSpace(card, 20);
        card.addView(registerLayout);

        main.addView(card, new LinearLayout.LayoutParams(
                -1, -2
        ));

        addSpace(main, 25);
        main.addView(footer);

        scrollView.addView(main);
        setContentView(scrollView);

        login.setOnClickListener(v -> {

            String user = username.getText().toString().trim();
            String pass = password.getText().toString();

            if (user.equals("admin") && pass.equals("admin123")) {

                Intent intent = new Intent(
                        MainActivity.this,
                        DashboardActivity.class
                );

                startActivity(intent);
                finish();

            } else if (user.equals("student123") && pass.equals("student123")) {

                Intent intent = new Intent(
                        MainActivity.this,
                        StudentDashboardActivity.class
                );

                startActivity(intent);
                finish();

            } else {

                Toast.makeText(
                        MainActivity.this,
                        "Invalid username or password.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        register.setOnClickListener(v -> {

            Intent intent = new Intent(
                    MainActivity.this,
                    StudentRegistrationActivity.class
            );

            startActivity(intent);
        });
    }

    void addSpace(LinearLayout layout, int height) {
        View space = new View(this);
        layout.addView(space, new LinearLayout.LayoutParams(
                1, dp(height)
        ));
    }
}
