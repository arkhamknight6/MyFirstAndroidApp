
package com.olicia.studentinformationsystem;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class StudentDashboardActivity extends Activity {

    int charcoal = Color.rgb(32, 32, 32);
    int background = Color.rgb(244, 240, 230);
    int gray = Color.rgb(133, 136, 139);
    int white = Color.WHITE;
    int border = Color.rgb(226, 224, 218);

    int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(charcoal);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        );

        showDashboard();
    }

    GradientDrawable createBackground(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    GradientDrawable createBorder(int color, int stroke, int radius) {
        GradientDrawable drawable = createBackground(color, radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    TextView createText(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setTypeface(Typeface.create(
                bold ? "sans-serif-medium" : "sans-serif",
                Typeface.NORMAL
        ));
        return text;
    }

    void showDashboard() {

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(background);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(24), dp(35), dp(24), dp(30));

        TextView logo = createText(
                "S T U D E N T   I N F O R M A T I O N   S Y S T E M",
                10, gray, true
        );

        TextView studentLabel = createText(
                "STUDENT PORTAL", 11, gray, true
        );

        TextView welcome = createText(
                "Welcome back,\nRoyce.",
                31, charcoal, true
        );

        TextView subtitle = createText(
                "Your academic information at a glance.",
                14, gray, false
        );

        LinearLayout banner = new LinearLayout(this);
        banner.setOrientation(LinearLayout.VERTICAL);
        banner.setPadding(dp(22), dp(25), dp(22), dp(25));
        banner.setBackground(createBackground(charcoal, 22));
        banner.setElevation(dp(3));

        TextView bannerLabel = createText(
                "ACADEMIC PROFILE",
                11, Color.rgb(205, 205, 205), true
        );

        TextView bannerName = createText(
                "Ledesma, Royce\nChristian S.",
                24, white, true
        );

        TextView bannerProgram = createText(
                "BSCS-ML  •  3rd Year",
                13, Color.rgb(215, 215, 215), false
        );

        banner.addView(bannerLabel);
        addSpace(banner, 18);
        banner.addView(bannerName);
        addSpace(banner, 10);
        banner.addView(bannerProgram);

        TextView sectionTitle = createText(
                "Personal Information", 20, charcoal, true
        );

        LinearLayout informationCard = new LinearLayout(this);
        informationCard.setOrientation(LinearLayout.VERTICAL);
        informationCard.setPadding(dp(21), dp(24), dp(21), dp(10));
        informationCard.setBackground(createBorder(white, border, 20));
        informationCard.setElevation(dp(2));

        addInformation(
                informationCard,
                "STUDENT NUMBER",
                "2024-1008033"
        );

        addDivider(informationCard);

        addInformation(
                informationCard,
                "STUDENT NAME",
                "Ledesma, Royce Christian S."
        );

        addDivider(informationCard);

        addInformation(
                informationCard,
                "PROGRAM / SPECIALIZATION",
                "BSCS-ML"
        );

        addDivider(informationCard);

        addInformation(
                informationCard,
                "YEAR LEVEL",
                "3rd Year"
        );

        TextView logout = createText(
                "LOG OUT     →", 14, white, true
        );

        logout.setGravity(Gravity.CENTER);
        logout.setBackground(createBackground(charcoal, 14));
        logout.setMinHeight(dp(58));
        logout.setClickable(true);
        logout.setFocusable(true);
        logout.setElevation(dp(2));

        TextView footer = createText(
                "STUDENT INFORMATION SYSTEM  •  2026",
                10, gray, true
        );
        footer.setGravity(Gravity.CENTER);

        main.addView(logo);
        addSpace(main, 30);
        main.addView(studentLabel);
        addSpace(main, 10);
        main.addView(welcome);
        addSpace(main, 10);
        main.addView(subtitle);
        addSpace(main, 30);
        main.addView(banner);
        addSpace(main, 30);
        main.addView(sectionTitle);
        addSpace(main, 15);
        main.addView(informationCard);
        addSpace(main, 25);
        main.addView(logout);
        addSpace(main, 25);
        main.addView(footer);

        scrollView.addView(main);
        setContentView(scrollView);

        logout.setOnClickListener(v -> {

            Intent intent = new Intent(
                    StudentDashboardActivity.this,
                    MainActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
            );

            startActivity(intent);
            finish();
        });
    }

    void addInformation(
            LinearLayout card,
            String label,
            String value
    ) {

        TextView labelText = createText(
                label, 10, gray, true
        );

        TextView valueText = createText(
                value, 15, charcoal, true
        );

        valueText.setLineSpacing(dp(3), 1);

        card.addView(labelText);
        addSpace(card, 8);
        card.addView(valueText);
        addSpace(card, 20);
    }

    void addDivider(LinearLayout layout) {
        View divider = new View(this);
        divider.setBackgroundColor(border);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        -1, dp(1)
                );

        params.bottomMargin = dp(18);
        layout.addView(divider, params);
    }

    void addSpace(LinearLayout layout, int height) {
        View space = new View(this);
        layout.addView(space, new LinearLayout.LayoutParams(
                1, dp(height)
        ));
    }
}
