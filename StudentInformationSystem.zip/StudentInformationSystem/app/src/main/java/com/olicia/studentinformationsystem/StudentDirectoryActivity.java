
package com.olicia.studentinformationsystem;

import android.app.Activity;
import android.os.Bundle;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class StudentDirectoryActivity extends Activity {

    int primary = Color.rgb(82, 107, 93);
    int background = Color.rgb(247, 246, 242);
    int dark = Color.rgb(41, 46, 42);
    int gray = Color.rgb(133, 139, 133);
    int white = Color.WHITE;

    DatabaseHelper databaseHelper;
    LinearLayout studentContainer;
    TextView totalCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseHelper = new DatabaseHelper(this);

        showDirectory();
        loadStudents();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (studentContainer != null) {
            loadStudents();
        }
    }

    GradientDrawable createBackground(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    TextView createText(String value, int size, int color) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        return text;
    }

    void showDirectory() {

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(25, 30, 25, 25);
        main.setBackgroundColor(background);

        TextView logo = createText(
                "STUDENT INFORMATION SYSTEM", 12, primary
        );
        logo.setTypeface(null, Typeface.BOLD);

        TextView title = createText(
                "Student Directory", 27, dark
        );
        title.setTypeface(null, Typeface.BOLD);

        TextView subtitle = createText(
                "View all registered students.", 14, gray
        );

        LinearLayout countCard = new LinearLayout(this);
        countCard.setOrientation(LinearLayout.VERTICAL);
        countCard.setPadding(20, 18, 20, 18);
        countCard.setBackground(createBackground(white, 18));

        TextView countLabel = createText(
                "TOTAL REGISTERED STUDENTS", 12, gray
        );
        countLabel.setTypeface(null, Typeface.BOLD);

        totalCount = createText("0 Students", 24, primary);
        totalCount.setTypeface(null, Typeface.BOLD);

        countCard.addView(countLabel);
        countCard.addView(totalCount);

        TextView listTitle = createText(
                "Registered Students", 19, dark
        );
        listTitle.setTypeface(null, Typeface.BOLD);

        ScrollView scrollView = new ScrollView(this);

        studentContainer = new LinearLayout(this);
        studentContainer.setOrientation(LinearLayout.VERTICAL);

        scrollView.addView(studentContainer);

        main.addView(logo);
        addSpace(main, 25);
        main.addView(title);
        addSpace(main, 6);
        main.addView(subtitle);
        addSpace(main, 25);
        main.addView(countCard);
        addSpace(main, 25);
        main.addView(listTitle);
        addSpace(main, 15);

        main.addView(scrollView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1
        ));

        TextView backButton = createText(
                "←  Back to Dashboard", 15, primary
        );
        backButton.setTypeface(null, Typeface.BOLD);
        backButton.setPadding(5, 20, 5, 10);
        backButton.setClickable(true);
        backButton.setFocusable(true);

        main.addView(backButton);

        backButton.setOnClickListener(v -> finish());

        setContentView(main);
    }

    void loadStudents() {

        studentContainer.removeAllViews();

        Cursor cursor = databaseHelper.getAllStudents();

        int count = 0;

        if (cursor != null) {

            if (cursor.moveToFirst()) {

                do {

                    String studentNo = cursor.getString(
                            cursor.getColumnIndexOrThrow("student_no")
                    );

                    String lastname = cursor.getString(
                            cursor.getColumnIndexOrThrow("lastname")
                    );

                    String firstname = cursor.getString(
                            cursor.getColumnIndexOrThrow("firstname")
                    );

                    String middlename = cursor.getString(
                            cursor.getColumnIndexOrThrow("middlename")
                    );

                    String program = cursor.getString(
                            cursor.getColumnIndexOrThrow("program")
                    );

                    String yearLevel = cursor.getString(
                            cursor.getColumnIndexOrThrow("year_level")
                    );

                    addStudentCard(
                            studentNo,
                            lastname,
                            firstname,
                            middlename,
                            program,
                            yearLevel
                    );

                    count++;

                } while (cursor.moveToNext());
            }

            cursor.close();
        }

        totalCount.setText(
                count + (count == 1 ? " Student" : " Students")
        );

        if (count == 0) {
            TextView emptyMessage = createText(
                    "No registered students found.", 14, gray
            );
            emptyMessage.setPadding(10, 25, 10, 25);
            studentContainer.addView(emptyMessage);
        }
    }

    void addStudentCard(
            String studentNo,
            String lastname,
            String firstname,
            String middlename,
            String program,
            String yearLevel
    ) {

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(20, 20, 20, 20);
        card.setBackground(createBackground(white, 18));

        String fullName = lastname + ", " + firstname;

        if (middlename != null && !middlename.trim().isEmpty()) {
            fullName += " " + middlename;
        }

        TextView name = createText(
                fullName, 17, dark
        );
        name.setTypeface(null, Typeface.BOLD);

        TextView number = createText(
                "Student No. " + studentNo, 13, gray
        );

        View divider = new View(this);
        divider.setBackgroundColor(background);

        card.addView(name);
        addSpace(card, 8);
        card.addView(number);
        addSpace(card, 15);

        card.addView(divider, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1
        ));

        addSpace(card, 12);

        TextView academicTitle = createText(
                "ACADEMIC INFORMATION", 11, primary
        );
        academicTitle.setTypeface(null, Typeface.BOLD);

        TextView programText = createText(
                "Program: " + program, 14, dark
        );

        TextView yearText = createText(
                "Year Level: " + yearLevel, 14, dark
        );

        card.addView(academicTitle);
        addSpace(card, 8);
        card.addView(programText);
        addSpace(card, 5);
        card.addView(yearText);

        studentContainer.addView(card);
        addSpace(studentContainer, 12);
    }

    void addSpace(LinearLayout layout, int height) {
        View space = new View(this);
        layout.addView(space, new LinearLayout.LayoutParams(1, height));
    }
}
