
package com.olicia.studentinformationsystem;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.DigitsKeyListener;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class StudentRegistrationActivity extends Activity {

    int charcoal = Color.rgb(32, 32, 32);
    int background = Color.rgb(244, 240, 230);
    int gray = Color.rgb(133, 136, 139);
    int white = Color.WHITE;
    int border = Color.rgb(226, 224, 218);

    DatabaseHelper databaseHelper;

    EditText studentNumber;
    EditText firstName;
    EditText middleName;
    EditText lastName;

    Spinner program;
    Spinner yearLevel;

    boolean isFormatting = false;

    int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        databaseHelper = new DatabaseHelper(this);

        getWindow().setStatusBarColor(background);
        getWindow().setNavigationBarColor(charcoal);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        );

        showRegistration();
    }

    GradientDrawable createBackground(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radius));
        return drawable;
    }

    GradientDrawable createBorder(int color, int stroke, int radius) {
        GradientDrawable drawable = createBackground(color, radius);
        drawable.setStroke(dp(1), stroke);
        return drawable;
    }

    TextView createText(String value, int size, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setTypeface(Typeface.create(
                bold ? "sans-serif-medium" : "sans-serif",
                Typeface.NORMAL
        ));
        return text;
    }

    EditText createInput(String hint, int inputType) {
        EditText input = new EditText(this);
        input.setHint(hint);
        input.setTextSize(14);
        input.setSingleLine(true);
        input.setInputType(inputType);
        input.setPadding(dp(16), dp(10), dp(16), dp(10));
        input.setTextColor(charcoal);
        input.setHintTextColor(gray);
        input.setBackground(createBorder(white, border, 14));
        input.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        return input;
    }

    Spinner createSpinner(String[] options) {
        Spinner spinner = new Spinner(this);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                options
        );

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinner.setAdapter(adapter);
        spinner.setBackground(createBorder(white, border, 14));
        spinner.setPadding(dp(12), 0, dp(12), 0);

        return spinner;
    }

    void showRegistration() {

        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(background);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(24), dp(25), dp(24), dp(35));

        TextView back = createText(
                "←  BACK TO DASHBOARD", 11, gray, true
        );
        back.setPadding(0, dp(10), 0, dp(10));
        back.setClickable(true);
        back.setOnClickListener(v -> finish());

        TextView logo = createText(
                "S T U D E N T   I N F O R M A T I O N",
                10, gray, true
        );

        TextView brand = createText(
                "S Y S T E M", 10, charcoal, true
        );

        TextView title = createText(
                "Student\nRegistration", 32, charcoal, true
        );

        TextView subtitle = createText(
                "Enter the student's personal and academic information.",
                14, gray, false
        );
        subtitle.setLineSpacing(dp(4), 1);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(25), dp(20), dp(25));
        card.setBackground(createBackground(white, 22));
        card.setElevation(dp(3));

        TextView section = createText(
                "PERSONAL INFORMATION", 11, gray, true
        );

        studentNumber = createInput(
                "YYYY-XXXXXXX",
                InputType.TYPE_CLASS_NUMBER
        );

        studentNumber.setKeyListener(
                DigitsKeyListener.getInstance("0123456789-")
        );

        addStudentNumberFormatter();

        firstName = createInput(
                "Enter first name",
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_FLAG_CAP_WORDS
        );

        middleName = createInput(
                "Enter middle name (optional)",
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_FLAG_CAP_WORDS
        );

        lastName = createInput(
                "Enter last name",
                InputType.TYPE_CLASS_TEXT |
                        InputType.TYPE_TEXT_FLAG_CAP_WORDS
        );

        program = createSpinner(new String[]{
                "BSCS-ML",
                "BSCS-DF"
        });

        yearLevel = createSpinner(new String[]{
                "1st Year",
                "2nd Year",
                "3rd Year",
                "4th Year"
        });

        card.addView(section);
        addSpace(card, 25);

        addField(card, "STUDENT NUMBER", studentNumber);
        addSpace(card, 18);

        addField(card, "FIRST NAME", firstName);
        addSpace(card, 18);

        addField(card, "MIDDLE NAME", middleName);
        addSpace(card, 18);

        addField(card, "LAST NAME", lastName);
        addSpace(card, 18);

        addLabel(card, "PROGRAM / SPECIALIZATION");
        card.addView(program, new LinearLayout.LayoutParams(
                -1, dp(55)
        ));

        addSpace(card, 18);

        addLabel(card, "YEAR LEVEL");
        card.addView(yearLevel, new LinearLayout.LayoutParams(
                -1, dp(55)
        ));

        addSpace(card, 30);

        TextView registerButton = createText(
                "REGISTER STUDENT     →", 14, white, true
        );

        registerButton.setGravity(Gravity.CENTER);
        registerButton.setBackground(createBackground(charcoal, 14));
        registerButton.setMinHeight(dp(58));
        registerButton.setClickable(true);
        registerButton.setFocusable(true);
        registerButton.setElevation(dp(2));

        card.addView(registerButton, new LinearLayout.LayoutParams(
                -1, dp(58)
        ));

        main.addView(back);
        addSpace(main, 25);
        main.addView(logo);
        main.addView(brand);
        addSpace(main, 20);
        main.addView(title);
        addSpace(main, 10);
        main.addView(subtitle);
        addSpace(main, 30);
        main.addView(card);
        addSpace(main, 25);

        TextView footer = createText(
                "STUDENT INFORMATION SYSTEM  •  2026",
                10, gray, true
        );
        footer.setGravity(Gravity.CENTER);
        main.addView(footer);

        scrollView.addView(main);
        setContentView(scrollView);

        registerButton.setOnClickListener(v -> registerStudent());
    }

    void addStudentNumberFormatter() {

        studentNumber.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(
                    CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable editable) {

                if (isFormatting) {
                    return;
                }

                String original = editable.toString();
                String digits = original.replaceAll("[^0-9]", "");

                String formatted;

                if (digits.length() > 4) {
                    formatted = digits.substring(0, 4) + "-" +
                            digits.substring(4);
                } else {
                    formatted = digits;
                }

                if (!original.equals(formatted)) {
                    isFormatting = true;
                    studentNumber.setText(formatted);
                    studentNumber.setSelection(formatted.length());
                    isFormatting = false;
                }
            }
        });
    }

    void addField(
            LinearLayout layout,
            String label,
            EditText input
    ) {
        addLabel(layout, label);
        layout.addView(input, new LinearLayout.LayoutParams(
                -1, dp(55)
        ));
    }

    void addLabel(LinearLayout layout, String value) {
        TextView label = createText(value, 10, gray, true);
        layout.addView(label);
        addSpace(layout, 8);
    }

    void addSpace(LinearLayout layout, int height) {
        View space = new View(this);
        layout.addView(space, new LinearLayout.LayoutParams(
                1, dp(height)
        ));
    }

    void registerStudent() {

        String studentNo = studentNumber.getText().toString().trim();
        String first = firstName.getText().toString().trim();
        String middle = middleName.getText().toString().trim();
        String last = lastName.getText().toString().trim();

        String selectedProgram = program.getSelectedItem().toString();
        String selectedYear = yearLevel.getSelectedItem().toString();

        if (studentNo.isEmpty() || first.isEmpty() || last.isEmpty()) {
            Toast.makeText(
                    this,
                    "Please fill in all required fields.",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        if (!studentNo.matches("[0-9]{4}-[0-9]+")) {
            studentNumber.setError(
                    "Format must be 4 digits followed by a hyphen and digits."
            );
            studentNumber.requestFocus();
            return;
        }

        boolean success = databaseHelper.addStudent(
                studentNo,
                last,
                first,
                middle,
                selectedProgram,
                selectedYear
        );

        if (success) {

            Toast.makeText(
                    this,
                    "Student registered successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            studentNumber.setText("");
            firstName.setText("");
            middleName.setText("");
            lastName.setText("");
            program.setSelection(0);
            yearLevel.setSelection(0);

        } else {

            Toast.makeText(
                    this,
                    "Student number already exists or registration failed.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }
}
